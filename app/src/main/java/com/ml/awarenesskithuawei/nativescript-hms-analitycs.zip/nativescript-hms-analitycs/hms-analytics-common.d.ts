import { ContentView, Property } from "@nativescript/core";

export declare class HMSAnalyticsWrapper {
    constructor();
    getAnalyticsInstanceId(): Promise<string>;
}