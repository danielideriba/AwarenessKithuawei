exports.SEED_LOCATION = "../";
exports.SEED_COPY_LOCATION = "seed-copy";
exports.SEED_TESTS_LOCATION = "seed-tests";
exports.DEFAULT_PLUGIN_NAME = "nativescript-yourplugin";
exports.TEST_PLUGIN_NAME = "ThePlugin";
exports.TEST_GITHUB_USERNAME = "TheGitHubUser";
jasmine.DEFAULT_TIMEOUT_INTERVAL = 1200000; // 20 mins