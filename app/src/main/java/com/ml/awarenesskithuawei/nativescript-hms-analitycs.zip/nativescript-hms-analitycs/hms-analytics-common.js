import { ContentView, Property } from "@nativescript/core";

export class HMSAnalyticsWrapper {
    getAnalyticsInstanceId() {
        
    }
}